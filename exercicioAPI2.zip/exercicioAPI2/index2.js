const express = require('express');

const app = express();

app.get("/", (req, res)=>{
    res.send('hello world 2');
});

app.get("/editar/:salarioBruto", (req, res) => {
    
    const {salarioBruto} = req.params;
    
    calcularSalarioLiquido(salarioBruto);

    function calcularDescontoINSS(salarioBruto) {
        let desconto = 0;
        if (salarioBruto <= 1412.0) {
          desconto = salarioBruto * 0.075;
        } else if (salarioBruto <= 2666.68) {
          desconto = salarioBruto * 0.09 - 21.18;
        } else if (salarioBruto <= 4000.03) {
          desconto = salarioBruto * 0.12 - 101.18;
        } else if (salarioBruto <= 7786.02 ) {
          desconto = salarioBruto * 0.14 - 181.18;
        } else {
          desconto = 7786.02 * 0.14; 
        }
      
        return desconto;
      }
      
      function calcularDescontoIR(salarioBase) {
        let descontoIR = 0;
        const faixa1 = 2112.00;
        const faixa2 = 2826.65;
        const faixa3 = 3751.05;
        const faixa4 = 4664.68;
      
        if (salarioBase <= faixa1) {
          descontoIR = 0;
        } else if (salarioBase <= faixa2) {
          descontoIR = (salarioBase - faixa1) * 0.075 - 158.40;
        } else if (salarioBase <= faixa3) {
          descontoIR = (salarioBase - faixa2) * 0.15 - 370.40;
        } else if (salarioBase <= faixa4) {
          descontoIR = (salarioBase - faixa3) * 0.225 - 651.73;
        } else {
          descontoIR = (salarioBase - faixa4) * 0.275 - 884.96;
        }
      
        return descontoIR;
      }
      
      
      function calcularSalarioLiquido(salarioBruto) {
        const descontoINSS = calcularDescontoINSS(salarioBruto);
        const salarioBase = salarioBruto - descontoINSS;
        const descontoIR = calcularDescontoIR(salarioBase);
        const salarioLiquido = salarioBase - descontoIR;
      
        res.send(`
            Salário Bruto: ${salarioBruto}<br>
            Salário Base: ${salarioBase}<br>
            Desconto IR: ${descontoIR}<br>
            Salário Líquido: ${salarioLiquido}<br>
            Desconto INSS: ${descontoINSS}<br>
          `);
          
      }
    

});

app.listen(8082, ()=>{
    console.log('servidor iniciado na porta 8082');
});


