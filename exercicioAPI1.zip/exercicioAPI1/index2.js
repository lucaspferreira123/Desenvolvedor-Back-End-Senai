const express = require('express');

const app = express();

app.get("/editar/:nome/:idade", (req, res) => {

    const { nome, idade } = req.params;
    if (idade >= 18) {
        res.send(`o usuario ${(nome)} é maior de idade, tem ${idade} anos`);
    } else {
        res.send(`o usuario ${nome} é menor de idade, tem ${idade} anos`);
    }

});

app.listen(8082, () => {
    console.log('servidor iniciado na porta 8082');
});