const express = require('express');

const app = express();

app.post("/", (req, res) => {
    res.send('hello world 2');
});

app.use(express.json());

app.post("/cadastrar", (req, res) => {

    const { nome, preco, tipo } = req.body;

    let imposto = 0;
    let precoFinal = 0;

    switch (tipo) {
        case "Eletrônicos":
            imposto = preco * 0.20;
            precoFinal = preco + imposto;
            break;

        case "Alimentícios":
            imposto = preco * 0.05;
            precoFinal = preco + imposto;
            break;

        case "Vestuário":
            imposto = preco * 0.10;
            precoFinal = preco + imposto;
            break;

        default:
            break;

        
    }

    res.send(`
        Produto: ${nome}<br>
        Valor: ${preco}<br>
        Tipo: ${tipo}<br>
        Preço Final: ${precoFinal}<br>
        Imposto: ${imposto}<br>`);

});

app.listen(8082, () => {
    console.log('servidor iniciado na porta 8082');
});