const http = require('http');

http.createServer((req, res)=>{
    res.end('hello world 1');
}).listen(8082);

console.log('servidor rodando');