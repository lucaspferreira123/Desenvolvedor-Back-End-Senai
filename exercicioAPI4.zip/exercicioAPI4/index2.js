const express = require('express');

const app = express();

app.post("/", (req, res) => {
    res.send('hello world 2');
});

app.use(express.json());

app.post("/cadastrar", (req, res) => {

    const { peso, altura } = req.body;

    let imc = peso / (altura * altura);

    if (imc < 18.5)
        res.send(`Abaixo do peso e IMC = ${imc}`);
    else if (imc >= 18.5 && imc <= 24.9)
        res.send(`Peso normal e IMC = ${imc}`);
    else if (imc >= 25 && imc <= 29.9)
        res.send(`Sobrepeso e IMC = ${imc}`);
    else if (imc >= 30 && imc <= 34.9)
        res.send(`Obesidade grau 1 e IMC = ${imc}`);
    else if (imc >= 35 && imc <= 39.9)
        res.send(`Obesidade grau 2 e IMC = ${imc}`);
    else (imc > 40)
        res.send(`Obesidade grau 3 e IMC = ${imc}`);
    

});

app.listen(8082, () => {
    console.log('servidor iniciado na porta 8082');
});